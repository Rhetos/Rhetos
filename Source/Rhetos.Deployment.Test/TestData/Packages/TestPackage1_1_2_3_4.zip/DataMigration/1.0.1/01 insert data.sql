INSERT INTO Test.RegularTable (Name) values('Name 1')
INSERT INTO Test.RegularTable (Name) values('Name 2')
INSERT INTO Test.RegularTable (Name) values('Name 3')
